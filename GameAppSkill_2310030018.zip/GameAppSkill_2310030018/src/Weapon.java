abstract class Weapon {
    public abstract void use();
}