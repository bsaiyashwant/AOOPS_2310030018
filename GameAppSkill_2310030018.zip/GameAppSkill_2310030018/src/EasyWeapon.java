class EasyWeapon extends Weapon {
    @Override
    public void use() {
        System.out.println("Easy Weapon used: Low damage");
    }
}