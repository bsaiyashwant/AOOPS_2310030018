public class MainGame {
    public static void main(String[] args) {
        // Create Easy Level items
        GameItemFactory easyFactory = new EasyLevelFactory();
        Weapon easyWeapon = easyFactory.createWeapon();
        PowerUp easyPowerUp = easyFactory.createPowerUp();

        easyWeapon.use();
        easyPowerUp.activate();

        System.out.println(); // Add a separator for better readability

        // Create Hard Level items
        GameItemFactory hardFactory = new HardLevelFactory();
        Weapon hardWeapon = hardFactory.createWeapon();
        PowerUp hardPowerUp = hardFactory.createPowerUp();

        hardWeapon.use();
        hardPowerUp.activate();
    }
}