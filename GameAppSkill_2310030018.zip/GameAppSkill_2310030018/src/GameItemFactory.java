interface GameItemFactory {
    Weapon createWeapon();
    PowerUp createPowerUp();
}