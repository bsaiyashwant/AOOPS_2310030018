/**
 * 
 */
/**
 * 
 */
module MusicStreamingApp {
}