package com.musicstreamingapp;

public class LocalFilePlayer {
    public void startPlaying() {
        System.out.println("Playing local file...");
    }

    public void stopPlaying() {
        System.out.println("Stopped playing local file.");
    }
}
