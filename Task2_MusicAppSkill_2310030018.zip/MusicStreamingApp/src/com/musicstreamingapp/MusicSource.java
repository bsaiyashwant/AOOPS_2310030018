package com.musicstreamingapp;

public interface MusicSource {
    void play();
    void stop();
    String getSourceInfo();
}
